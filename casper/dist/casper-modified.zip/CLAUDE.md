## Explanation
This project is a customized casper theme (one of the default themes) for Ghost blogging. I want to adjust it to suite my need and add some aesthetic visual into the theme.
### Theme verification
Before uploading the theme, it must be verified via gscan.ghost.org
In order to verify it, we will have to create a zip file by running `npm run zip` which invokes gulp zip, this requires us restore the npm packages via `npm install -f`

## Rules
- Do not automatically commit and push code
- Do not make assumptions on things that are not documented
- Explicitly mark "Unsure" when you are not 100% sure when giving the statement. 
- Respect the .gitignore file and do not search content that is ignored by git unless it's .env

## About the Theme and layout
I want the theme to have 2 different layouts for the portrait mode and landscape mode which is already implemented.
The hero section has a video tag which is auto play as background. The initial intention was to use gif but the gif file was huge and not as optimized (in size and also code support) as video.
